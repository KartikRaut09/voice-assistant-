# 🔊 Voice Assistant in Python

This project is a simple yet functional voice assistant built using Python. It leverages speech recognition and text-to-speech technologies to allow users to interact with their computer using voice commands.

The assistant listens to spoken input, processes commands, and responds with appropriate actions or voice feedback. It's designed to be modular and easy to extend, making it a great starting point for more advanced AI assistant projects.

## ✨ Features
- Convert speech to text using the `SpeechRecognition` library
- Respond with synthesized speech using `pyttsx3`
- Organize logic into modular scripts for maintainability
- Customize responses using a plain text file (`jarvis.txt`)

## 📦 Technologies Used
- Python 3
- `pyttsx3` for text-to-speech
- `SpeechRecognition` for converting audio input
- `PyAudio` for microphone access

## 🛠 How to Use
1. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Run the Assistant**
   ```bash
   python voice_assistant.py
   ```

## 📁 Key Files
- `voice_assistant.py`: Main application logic
- `blocks.py`: Contains individual command logic
- `programflow.py`: Manages control flow
- `jarvis.txt`: Customizable voice responses
- `requirements.txt`: Python dependencies

---

This project is ideal for beginners in Python and AI who want to explore voice interaction and modular programming. Feel free to fork, customize, and expand on it.
