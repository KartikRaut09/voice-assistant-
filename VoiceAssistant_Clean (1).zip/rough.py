print("the python is the future ")
print()
print("the web development is very useful for future ")